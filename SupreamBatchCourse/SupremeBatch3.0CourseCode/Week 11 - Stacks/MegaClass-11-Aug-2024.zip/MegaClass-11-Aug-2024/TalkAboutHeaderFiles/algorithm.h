// algorithm.h
#ifndef ALGORITHM_H // guard
#define ALGORITHM_H

void sort(int arr[], int n); // declaration

#endif // ALGORITHM_H
