#include "algorithm.h"
#include <iostream>

void sort(int arr[], int n)
{
    // palak ka international patented sort algo.
    std::cout << "palak ka international patented sort algo." << std::endl;
    return;
}