#include<iostream>
using namespace std;


int main() {


    string s1 = "love";
    string s2 = "amit";

    cout << s1.compare(s2) << endl;

    // string name = "Hello Jee Kaise ho Saare" ;
    // string word = "Kaise ho";

    // if(name.find(word) != string::npos) {
    //     ///found
    // }
    // else {
    //     //not found
    // }
    

    // int ans = name.find(word);
    // cout << ans << endl;

    // cout << name.substr(5);

    //position and upto len
    // cout << name.substr(5,5);

    // string fName = "Love";
    // string lName = "babbar";

    // string ans = fName + " " + lName;
    // cout << ans << endl;

    // string name = "Maharana Pratap";
    // name.clear();
    // if(name.empty() ){
    //     cout << "String is empty" ; 
    // }
    // else {
    //     cout << "string is not empty";
    // }



    // auto it = name.begin();

    // while(it != name.end()) {
    //     cout << *it << " ";
    //     it++;
    // }
    // cout << endl;



    // cout << name[0] << endl;
    // cout << name.at(0) << endl;

    // cout << name.front() << endl;
    // cout << name.back() << endl;
    // cout << name.length() << endl;







    // string sentence;

    // //cin >> sentence;
    // getline(cin, sentence, '\n');

    // cout << sentence << endl;




    //creation
    // string str;
    // str.push_back('l');
    // str.push_back('o');
    // str.push_back('v');
    // str.push_back('e');
    // str.pop_back();
    // cout << str << endl;
    
    // cout << "enter the input" << endl;
    // //input
    // cin >> str;
    // //output
    // cout << "Str: " << str << endl;
    // cout << str[0] << endl;



    return 0;
}